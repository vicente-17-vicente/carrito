<?php
// SDK de Mercado Pago
require __DIR__ .  '/mercadopago/vendor/autoload.php';

// Agrega credenciales
//Prueba
//MercadoPago\SDK::setAccessToken('TEST-1082926972556745-110403-df9a24781f56a0d88028b6749c07bc44-659186177');

//Produccion
MercadoPago\SDK::setAccessToken('APP_USR-1082926972556745-110403-e0016b54716d89ecc7c93e202a11d761-659186177');

// Datos de usuario
$payer = new MercadoPago\Payer();
$payer->name = "Charles";
$payer->surname = "Luevano";
$payer->email = "charles@hotmail.com";
$payer->date_created = "2018-06-02T12:58:41.425-04:00";
$payer->phone = array(
  "area_code" => "+52",
  "number" => "949 128 866"
);

$payer->address = array(
  "street_name" => "Cuesta Miguel Armendáriz",
  "street_number" => 1004,
  "zip_code" => "11020"
);
// ...


// Crea un objeto de preferencia
$preference = new MercadoPago\Preference();

//Url de Retorno
$preference->back_urls = array(
    "success" => "http://localhost/carrito/resultado.php?estado=success",
    "failure" => "http://localhost/carrito/resultado.php?estado=failure",
    "pending" => "http://localhost/carrito/resultado.php?estado=pending"
);
$preference->auto_return = "approved";
// ...

$hoy = date("Y-m-d");

$producto_nombre = htmlspecialchars($_POST['producto_nombre']);
$producto_precio = htmlspecialchars($_POST['producto_precio']);
$radio_periodo = htmlspecialchars($_POST['radio_periodo']);


$mes = number_format($producto_precio / 12, 2);
$trimestre = number_format($producto_precio / 4, 2);
$semestre = number_format($producto_precio / 6, 2);
$anual = number_format($producto_precio, 2);


if ($radio_periodo == "Anual") {
    $total_pagar = $anual;
    $periodo_final = date("Y-m-d", strtotime($hoy . "+ 12 month"));
} elseif ($radio_periodo == "Semestre") {
    $total_pagar = $semestre;
    $periodo_final = date("Y-m-d", strtotime($hoy . "+ 6 month"));
} elseif ($radio_periodo == "Trimestre") {
    $total_pagar = $trimestre;
    $periodo_final = date("Y-m-d", strtotime($hoy . "+ 3 month"));
} elseif ($radio_periodo == "Mensual") {
    $total_pagar = $mes;
    $periodo_final = date("Y-m-d", strtotime($hoy . "+ 1 month"));
}

//Crear usuarios prueba
//curl -X POST -H "Content-Type: application/json" "https://api.mercadopago.com/users/test_user?access_token=TEST-1082926972556745-110403-df9a24781f56a0d88028b6749c07bc44-659186177" -d "{"site_id":'MLM'}"
//usuario 1 Vendedor =  {"id":673621744,"nickname":"TETE2006074","password":"qatest4955","site_status":"active","email":"test_user_77083076@testuser.com"}
//usuario 2 Comprador =  {"id":673626248,"nickname":"TESTUF8Z6W2U","password":"qatest2734","site_status":"active","email":"test_user_41462727@testuser.com"}
//usuario 3 =  {"id":673626252,"nickname":"TETE7478990","password":"qatest8994","site_status":"active","email":"test_user_37330529@testuser.com"}

?>
<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v4.1.1">
    <title>Carrito example · Bootstrap</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/pricing.css" rel="stylesheet">
    <script src="https://www.mercadopago.com/v2/security.js" view="checkout"></script>

</head>

<body>
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
        <h5 class="my-0 mr-md-auto font-weight-normal">Carrito prueba</h5>
        <nav class="my-2 my-md-0 mr-md-3">
            <a class="p-2 text-dark" href="#">Features</a>
            <a class="p-2 text-dark" href="#">Enterprise</a>
            <a class="p-2 text-dark" href="#">Support</a>
            <a class="p-2 text-dark" href="#">Pricing</a>
        </nav>
        <a class="btn btn-outline-primary" href="#">Sign up</a>
    </div>


    <div class="container">
        <h2>Detalles de Compra</h2>
        <form action="resultado.php">
            <div class="form-group">
                <label>Producto</label>
                <input type="text" class="form-control" value="<?php echo $producto_nombre; ?>" disabled>
            </div>

            <div class="form-group">
                <label>Precio</label>
                <input type="text" class="form-control" value="<?php echo "$ " . $producto_precio . " MXN"; ?>" disabled>
            </div>

            <div class="form-group">
                <label>Periodo</label>
                <input type="text" class="form-control" value="<?php echo $radio_periodo; ?>" disabled>
            </div>

            <div class="form-group">
                <label>Fecha Inicio</label>
                <input type="date" class="form-control" value="<?php echo $hoy; ?>" disabled>
            </div>

            <div class="form-group">
                <label>Fecha Final</label>
                <input type="date" class="form-control" value="<?php echo $periodo_final; ?>" disabled>
            </div>

            <div class="form-group">
                <label>Total a pagar</label>
                <input type="text" class="form-control" value="<?php echo "$" . $total_pagar . " MXN"; ?>" disabled>
            </div>

            <?php
            // Crea un ítem en la preferencia
            $item = new MercadoPago\Item();
            $item->title = $producto_nombre;
            $item->quantity = 1;
            $item->unit_price = 10;
            $preference->items = array($item);
            $preference->save();
            ?>

            <script src="https://www.mercadopago.com.mx/integrations/v1/web-payment-checkout.js" data-preference-id="<?php echo $preference->id; ?>">
            </script>
        </form>

        <footer class="pt-4 my-md-5 pt-md-5 border-top">
            <div class="row">
                <div class="col-12 col-md">
                    <img class="mb-2" src="brand/bootstrap-solid.svg" alt="" width="24" height="24">
                    <small class="d-block mb-3 text-muted">&copy; 2017-2020</small>
                </div>
                <div class="col-6 col-md">
                    <h5>Features</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Cool stuff</a></li>
                        <li><a class="text-muted" href="#">Random feature</a></li>
                        <li><a class="text-muted" href="#">Team feature</a></li>
                        <li><a class="text-muted" href="#">Stuff for developers</a></li>
                        <li><a class="text-muted" href="#">Another one</a></li>
                        <li><a class="text-muted" href="#">Last time</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <h5>Resources</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Resource</a></li>
                        <li><a class="text-muted" href="#">Resource name</a></li>
                        <li><a class="text-muted" href="#">Another resource</a></li>
                        <li><a class="text-muted" href="#">Final resource</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <h5>About</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Team</a></li>
                        <li><a class="text-muted" href="#">Locations</a></li>
                        <li><a class="text-muted" href="#">Privacy</a></li>
                        <li><a class="text-muted" href="#">Terms</a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
</body>

</html>