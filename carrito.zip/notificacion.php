<?php
// Estos incluyen no tienen nada que ver con el proceso de notificación en sí.
$root = $_SERVER['DOCUMENT_ROOT'];

include "$root/api/connection.php";         // solo un script que se conecta a la base de datos
include "$root/api/constants.php";          // solo un archivo que contiene algunas constantes utilizadas aquí
include "$root/inc/extend-signature.php";   // solo un archivo que proporciona algunas funciones para mi sitio web


/*****************************************************************/
/********** Lo importante comienza desde aquí abajo **********/
/*****************************************************************/


/*
    lo único realmente necesario para recibir una notificación es esa variable $_GET['id']
    este es el 'merchant order id'
    obtendremos información sobre cada pago por POSTing this id to MercadoPago servers via cURL
    */

// Paso 1 -> Almacene el 'merchant order id' en una variable
$id = $_GET['id']; // la única variable realmente necesaria para recibir la notificación


// Paso 2 -> hacer un POST solicitud usando esto 'id' que almacenamos y tu MercadoPago 'access token' como parámetros
$curl = curl_init();

curl_setopt($curl, CURLOPT_URL, 'https://api.mercadopago.com//merchant_orders/' . $id . '?access_token=' . $MP_PRODUCTION_ACCESS_TOKEN);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// Paso 2.5 -> Almacenar la respuesta del servidor de MercadoPago en una variable
$result = json_decode(curl_exec($curl), true);

if (curl_errno($curl)) {
    echo 'Error:' . curl_error($curl);
}

curl_close($curl);


// Paso 3 -> Haz lo que necesites con los datos de respuesta

/*
   esto es lo que usé en mi sitio web, tome esto como ejemplo
     para que puedas entender mejor cómo MercadoPago envía la respuesta
     de aquí abajo hay un código que utilicé para mi sitio web
     no son instrucciones, solo ejemplos, y los comentarios son solo
     explicando lo que está sucediendo con el código en sí, no sobre el proceso de notificación
     Es una implementación que extiende una firma para un usuario.
     cuando el pago sea aprobado por MercadoPago
    */

// División cURL respuesta en variables
$merchant_order_id = $id;
$transaction_amount = $result["payments"][0]["transaction_amount"];
$date_created = $result["payments"][0]["date_created"];
$date_last_updated = $result["payments"][0]["last_modified"];
$status = $result["payments"][0]["status"];
$status_detail = $result["payments"][0]["status_detail"];
$collector_id = $result["collector"]["id"];

// Dar formato a las fechas
$date_created = new DateTime($date_created);
$date_created = $date_created->format("Y-m-d H:i:s");

$date_last_updated = new DateTime($date_last_updated);
$date_last_updated = $date_last_updated->format("Y-m-d H:i:s");

// Conéctese a la base de datos y realice consultas
//$conn = getConnection($RENT_YOUR_APP_DB);

$query = "SELECT * FROM $RENT_YOUR_APP_TABLE_PAYMENTS WHERE merchant_order_id = '$id'";

$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$res_count = count($result);

if ($res_count < 1) {
    $query = "INSERT INTO $RENT_YOUR_APP_TABLE_PAYMENTS(
            merchant_order_id,
            transaction_amount,
            status,
            status_detail,
            date_created,
            date_last_updated,
            collector_id
        ) VALUES(
            $merchant_order_id,
            $transaction_amount,
            '$status',
            '$status_detail',
            '$date_created',
            '$date_last_updated',
            '$collector_id'
        )";
} else if ($res_count == 1) {
    $query = "UPDATE $RENT_YOUR_APP_TABLE_PAYMENTS
            set transaction_amount = $transaction_amount,
            status = '$status',
            status_detail = '$status_detail',
            date_created = '$date_created',
            date_last_updated = '$date_last_updated',
            collector_id = '$collector_id'
            WHERE merchant_order_id = '$merchant_order_id'";
} else {
    die("SQL querry error");
}

$stmt = $conn->prepare($query);
$query_status = $stmt->execute() ? "Payment updated successfully<br>" : "Failed to update payment<br>";

if ($res_count == 1 && $status == 'approved' && $status_detail == 'accredited') {
    $query = "SELECT * FROM $RENT_YOUR_APP_TABLE_PAYMENTS WHERE merchant_order_id = '$id'";

    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($result) == 1) {
        $current_user_id = $result[0]["rya_user_id"];
        //$extendSignature($current_user_id);
    }
}
