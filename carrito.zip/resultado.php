<?php
date_default_timezone_set('America/Mexico_City');

include 'conex.php';

$hoy = date("Y-m-d H:i:s");

$estado_pago = htmlspecialchars($_GET['estado']);
$collection_id = htmlspecialchars($_GET['collection_id']);
$collection_status = htmlspecialchars($_GET['collection_status']);
$payment_id = htmlspecialchars($_GET['payment_id']);
$status = htmlspecialchars($_GET['status']);
$external_reference = htmlspecialchars($_GET['external_reference']);
$payment_type = htmlspecialchars($_GET['payment_type']);
$merchant_order_id = htmlspecialchars($_GET['merchant_order_id']);
$preference_id = htmlspecialchars($_GET['preference_id']);
$site_id = htmlspecialchars($_GET['site_id']);
$processing_mode = htmlspecialchars($_GET['processing_mode']);
$merchant_account_id = htmlspecialchars($_GET['merchant_account_id']);

$sql_resultado = "INSERT INTO pagos (estado, collection_id, collection_status, payment_id, status, external_reference,payment_type,merchant_order_id,preference_id, site_id, processing_mode, merchant_account_id, fecha) 
VALUES ('$estado_pago','$collection_id','$collection_status','$payment_id','$status','$external_reference','$payment_type',
'$merchant_order_id','$preference_id','$site_id','$processing_mode','$merchant_account_id','$hoy') ";

$result = mysqli_query($conexion, $sql_resultado);

if ($result) {
    echo "<script>alert('Estado de Pago $estado_pago');</script>";
    echo "<script>window.location.replace('pagos.php');</script>";
}else{
    echo "<script>alert('Error al insertar');</script>";
    echo "<script>window.location.replace('pagos.php');</script>";
}
