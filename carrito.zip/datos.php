<?php
$nombre_producto = htmlspecialchars($_GET['nombre']);
$precio_producto = htmlspecialchars($_GET['precio']);

$mes = number_format($precio_producto/12, 2);
$trimestre = number_format($precio_producto/4, 2);
$semestre = number_format($precio_producto/6, 2);
$anual = number_format($precio_producto, 2);
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v4.1.1">
    <title>Carrito example · Bootstrap</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/pricing/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/pricing.css" rel="stylesheet">

</head>
<body>
    <div class="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
        <h5 class="my-0 mr-md-auto font-weight-normal">Carrito prueba</h5>
        <nav class="my-2 my-md-0 mr-md-3">
            <a class="p-2 text-dark" href="#">Features</a>
            <a class="p-2 text-dark" href="#">Enterprise</a>
            <a class="p-2 text-dark" href="#">Support</a>
            <a class="p-2 text-dark" href="#">Pricing</a>
        </nav>
        <a class="btn btn-outline-primary" href="#">Sign up</a>
    </div>


    <div class="container">
        <h2>Paquete Seleccionado</h2>
        <form method="POST" action="checkout.php">
            <div class="form-group">
                <label>Producto</label>
                <input type="text" class="form-control" value="<?php echo $nombre_producto; ?>" name="producto_nombre" readonly>
            </div>

            <div class="form-group">
                <label>Precio</label>
                <input type="number" class="form-control" value="<?php echo $precio_producto; ?>" name="producto_precio" readonly>
            </div>

            <div class="form-group">
                <label>Periodo</label>

                <!-- Group of default radios - option 1 -->
                <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="defaultGroupExample1" name="radio_periodo" value="Mensual">
                    <label class="custom-control-label" for="defaultGroupExample1">Mes -- <?php echo "$".$mes; ?></label>
                </div>

                <!-- Group of default radios - option 2 -->
                <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="defaultGroupExample2" name="radio_periodo" value="Trimestre">
                    <label class="custom-control-label" for="defaultGroupExample2">Trimestre -- <?php echo "$".$trimestre; ?></label>
                </div>

                <!-- Group of default radios - option 3 -->
                <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="defaultGroupExample3" name="radio_periodo" value="Semetre">
                    <label class="custom-control-label" for="defaultGroupExample3">Semestre -- <?php echo "$".$semestre; ?></label>
                </div>

                <div class="custom-control custom-radio">
                    <input type="radio" class="custom-control-input" id="defaultGroupExample4" name="radio_periodo" checked value="Anual">
                    <label class="custom-control-label" for="defaultGroupExample4">Anual -- <?php echo "$".$anual; ?></label>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Siguiente</button>
        </form>

        <footer class="pt-4 my-md-5 pt-md-5 border-top">
            <div class="row">
                <div class="col-12 col-md">
                    <img class="mb-2" src="brand/bootstrap-solid.svg" alt="" width="24" height="24">
                    <small class="d-block mb-3 text-muted">&copy; 2017-2020</small>
                </div>
                <div class="col-6 col-md">
                    <h5>Features</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Cool stuff</a></li>
                        <li><a class="text-muted" href="#">Random feature</a></li>
                        <li><a class="text-muted" href="#">Team feature</a></li>
                        <li><a class="text-muted" href="#">Stuff for developers</a></li>
                        <li><a class="text-muted" href="#">Another one</a></li>
                        <li><a class="text-muted" href="#">Last time</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <h5>Resources</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Resource</a></li>
                        <li><a class="text-muted" href="#">Resource name</a></li>
                        <li><a class="text-muted" href="#">Another resource</a></li>
                        <li><a class="text-muted" href="#">Final resource</a></li>
                    </ul>
                </div>
                <div class="col-6 col-md">
                    <h5>About</h5>
                    <ul class="list-unstyled text-small">
                        <li><a class="text-muted" href="#">Team</a></li>
                        <li><a class="text-muted" href="#">Locations</a></li>
                        <li><a class="text-muted" href="#">Privacy</a></li>
                        <li><a class="text-muted" href="#">Terms</a></li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
</body>

</html>