<?php
ini_set('display_errors', 1);
$db_host = "localhost";
$db_name = "mercadopago";
$db_user = "root";
$db_password = "";
$conexion = mysqli_connect($db_host, $db_user, $db_password);
if (!$conexion) {
    die("NO SE PUDO CONECTAR A LA BASE" . mysqli_error($conexion));
}

function db_data()
{
    global $db_name;
    global $conexion;
    mysqli_select_db($conexion, $db_name);
    mysqli_query($conexion, "SET NAMES utf8");
    mysqli_query($conexion, "SET CHARACTER_SET utf8");
}

db_data();
