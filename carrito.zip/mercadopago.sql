-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-11-2020 a las 10:36:53
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mercadopago`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id` int(11) NOT NULL,
  `estado` varchar(45) NOT NULL,
  `collection_id` varchar(45) NOT NULL,
  `collection_status` varchar(45) NOT NULL,
  `payment_id` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  `external_reference` varchar(45) NOT NULL,
  `payment_type` varchar(45) NOT NULL,
  `merchant_order_id` varchar(45) NOT NULL,
  `preference_id` varchar(45) NOT NULL,
  `site_id` varchar(45) NOT NULL,
  `processing_mode` varchar(45) NOT NULL,
  `merchant_account_id` varchar(45) NOT NULL,
  `fecha` datetime(6) NOT NULL,
  `status_payment` varchar(45) NOT NULL,
  `order_status` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id`, `estado`, `collection_id`, `collection_status`, `payment_id`, `status`, `external_reference`, `payment_type`, `merchant_order_id`, `preference_id`, `site_id`, `processing_mode`, `merchant_account_id`, `fecha`, `status_payment`, `order_status`) VALUES
(1, 'success', '1231279574', 'approved', '1231279574', 'approved', 'null', 'credit_card', '2002973533', '659186177-c9f69999-e982-4b58-8cd5-411803f530b', 'MLM', 'aggregator', 'null', '2020-11-19 23:19:19.000000', 'opened', 'payment_required'),
(2, 'pending', '1231279594', 'in_process', '1231279594', 'in_process', 'null', 'credit_card', '2002978105', '659186177-67e8d149-e476-404e-88c9-55a4e950a77', 'MLM', 'aggregator', 'null', '2020-11-19 23:25:40.000000', 'opened', 'payment_required'),
(3, 'pending', '1231279620', 'pending', '1231279620', 'pending', 'null', 'ticket', '2002986951', '659186177-27742b32-f47c-4b42-bd07-91500f81c7e', 'MLM', 'aggregator', 'null', '2020-11-19 23:43:51.000000', 'opened', 'payment_required'),
(4, 'pending', '12342685693', 'pending', '12342685693', 'pending', 'null', 'ticket', '2003057932', '659186177-ec17bb9f-acf2-4066-8b16-146845736e1', 'MLM', 'aggregator', 'null', '2020-11-20 02:55:02.000000', 'closed', 'payment_in_process'),
(5, 'pending', '12342702339', 'pending', '12342702339', 'pending', 'null', 'ticket', '2003059737', '659186177-61753add-07bb-4ec7-b60b-2d31986d3d9', 'MLM', 'aggregator', 'null', '2020-11-20 02:58:19.000000', 'closed', 'payment_in_process'),
(6, 'pending', '12342728035', 'pending', '12342728035', 'pending', 'null', 'ticket', '2003064017', '659186177-2efdd3ac-bcf6-462a-9392-bf392e7f0e7', 'MLM', 'aggregator', 'null', '2020-11-20 03:03:47.000000', 'closed', 'payment_in_process');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
