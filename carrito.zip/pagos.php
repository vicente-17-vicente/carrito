<?php
include 'conex.php';
$token = "APP_USR-1082926972556745-110403-e0016b54716d89ecc7c93e202a11d761-659186177";

$sql_pagos = "SELECT * FROM pagos";
$consulta_pagos = mysqli_query($conexion, $sql_pagos);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <title>Estado de Pagos</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container">
        <h2>MercadoPago</h2>
        <p>Historial de pagos:</p>
        <a href="index.php" type="button" class="btn btn-primary">
            Inicio
        </a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>payment_id</th>
                    <th>merchant_order_id</th>
                    <th>Tipo de Pago</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row_pagos = mysqli_fetch_array($consulta_pagos, MYSQLI_ASSOC)) {
                    $id = $row_pagos['id'];
                    $payment_id = $row_pagos['payment_id'];
                    $merchant_order_id = $row_pagos['merchant_order_id'];
                    $estado_pago = $row_pagos['estado'];
                    $fecha_pago = $row_pagos['fecha'];
                    $tipo_pago = $row_pagos['payment_type'];

                    $date = new DateTime($fecha_pago);
                    $fecha = $date->format('d-m-Y H:i:s');

                    $url_json_merchant = "https://api.mercadopago.com/merchant_orders/$merchant_order_id?access_token=$token";

                    $curl = curl_init();

                    curl_setopt($curl, CURLOPT_URL, $url_json_merchant);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

                    // Paso 2.5 -> Almacenar la respuesta del servidor de MercadoPago en una variable
                    $result = json_decode(curl_exec($curl), true);

                    if (curl_errno($curl)) {
                        echo 'Error:' . curl_error($curl);
                    }

                    curl_close($curl);
                    $status_json = $result["status"];
                    $order_status = $result['order_status'];

                    $upd_pagos = "UPDATE pagos SET status_payment='$status_json', order_status='$order_status' WHERE id=$id";
                    $rst = mysqli_query($conexion, $upd_pagos);

                ?>
                    <tr>
                        <td><?php echo $id; ?></td>
                        <td><?php echo $payment_id; ?></td>
                        <td><?php echo $merchant_order_id; ?></td>
                        <td><?php echo $tipo_pago; ?></td>
                        <td><?php echo $estado_pago; ?></td>
                        <td><?php echo $fecha; ?></td>
                        <td>
                            <?php
                            if ($status_json) {
                            ?>
                                <a href="notificaciones.php?topic=merchant_orders&id=<?php echo $merchant_order_id; ?>" type="button" class="btn btn-success">
                                    Ver
                                </a>
                            <?php
                            } else {
                                echo "SIn Validar Pago";
                            }
                            ?>
                    </tr>

                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

</body>

</html>