<?php
// SDK de Mercado Pago
require __DIR__ .  '/mercadopago/vendor/autoload.php';

// Agrega credenciales
$token = "TEST-1082926972556745-110403-df9a24781f56a0d88028b6749c07bc44-659186177";
MercadoPago\SDK::setAccessToken($token);

$merchant_order = null;

switch ($_GET["topic"]) {
    case "payment":
        $payment = MercadoPago\Payment::find_by_id($_GET["id"]);
        // Obtenga el pago y la orden mercantil correspondiente reportados por el IPN.
        $merchant_order = MercadoPago\MerchantOrder::find_by_id($payment->order->id);
        break;
    case "merchant_order":
        $merchant_order = MercadoPago\MerchantOrder::find_by_id($_GET["id"]);
        break;
}

$paid_amount = 0;
foreach ($merchant_order->payments as $payment) {
    if ($payment['status'] == 'approved') {
        $paid_amount += $payment['transaction_amount'];
    }
}

// Si el monto de la transacción de pago es igual (o mayor) que el monto de los pedidos del comerciante, puede liberar sus artículos
if ($paid_amount >= $merchant_order->total_amount) {
    if (count($merchant_order->shipments) > 0) { // El pedido mercantil tiene envíos
        if ($merchant_order->shipments[0]->status == "ready_to_ship") {
            print_r("Totalmente pagado. Imprime la etiqueta y libera tu artículo.");
        }
    } else { // La orden mercantil no tiene envíos
        print_r("Totalmente pagado. Libera tu artículo.");
    }
} else {
    print_r("Aún no pagado. No sueltes tu artículo.");
}

$id = $_GET['id'];

$url_json_merchant = "https://api.mercadopago.com/merchant_orders/$id?access_token=$token";
$url_json_payment = "https://api.mercadopago.com/payment/$id?access_token=$token";
echo "<br>";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>
<body>
    <a href="pagos.php" type="button" class="btn btn-danger">
        Volver
    </a>

    <a href="<?php echo $url_json_merchant; ?>" type="button" class="btn btn-success" target="_blank">
        merchant_orders
    </a>

    <a href="<?php echo $url_json_payment; ?>" type="button" class="btn btn-primary" target="_blank">
        payment
    </a>
</body>

</html>
<?php 
$curl = curl_init();

curl_setopt($curl, CURLOPT_URL, $url_json_merchant);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// Paso 2.5 -> Almacenar la respuesta del servidor de MercadoPago en una variable
$result = json_decode(curl_exec($curl), true);

if (curl_errno($curl)) {
    echo 'Error:' . curl_error($curl);
}

curl_close($curl);

echo "<br>";
echo "<h1>Datos Json</h1>";
echo "status: ".$result["status"]."<br>";
echo "total_amount: ".$result["total_amount"]."<br>";
echo "cancelled: ".$result["cancelled"]."<br>";
echo "order_status: ".$result["order_status"]."<br>";


?>